import React, { Component } from 'react';
import { View,Text } from 'react-native';
import { Card } from 'react-native-elements';

class ListProduct extends Component {
    render() {
        // const { pname } = ;
        console.log(item);
        return (
            <View>
               <Text>try</Text>
            </View>
        )
    }
}

export default ListProduct;
